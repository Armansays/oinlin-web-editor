
document.getElementById('inputVel').addEventListener('keypress',function(){
   
    var vel0 = document.getElementById('inputVel').value;

    document.getElementById('output').srcdoc = vel0
    

})


